<?php

namespace Modules\AutomatedTimetable\Services;

use Illuminate\Support\Facades\DB;
use Exception;

class TimetableGeneratorService
{
    protected $school_id;
    protected $academic_id;

    public function __construct()
    {
        $this->school_id = auth()->check() ? auth()->user()->school_id : 1;
        $this->academic_id = auth()->check() ? auth()->user()->academic_id : 1;
    }

    /**
     * Generate Timetable for a specific class and section
     */
    public function generate($class_id, $section_id)
    {
        DB::beginTransaction();
        try {
            // 1. Clear existing routine for this class/section
            DB::table('sm_class_routine_updates')
                ->where('class_id', $class_id)
                ->where('section_id', $section_id)
                ->where('school_id', $this->school_id)
                ->delete();

            // 2. Fetch assigned subjects and teachers
            $assignedSubjects = DB::table('sm_assign_subjects')
                ->where('class_id', $class_id)
                ->where('section_id', $section_id)
                ->where('school_id', $this->school_id)
                ->whereNotNull('teacher_id')
                ->get();

            if ($assignedSubjects->isEmpty()) {
                throw new Exception("No assigned subjects for this class and section.");
            }

            // 3. Fetch rules (required periods) or default to 5
            $rules = DB::table('timetable_rules')
                ->where('class_id', $class_id)
                ->where('section_id', $section_id)
                ->where('school_id', $this->school_id)
                ->get()->keyBy('subject_id');

            // Build request pool: how many periods needed for each subject
            $pool = [];
            foreach ($assignedSubjects as $subj) {
                $required = isset($rules[$subj->subject_id]) ? $rules[$subj->subject_id]->required_periods : 5; // Default 5 periods/week
                for ($i = 0; $i < $required; $i++) {
                    $pool[] = [
                        'subject_id' => $subj->subject_id,
                        'teacher_id' => $subj->teacher_id
                    ];
                }
            }

            // 4. Fetch available Class Times (slots)
            $classTimes = DB::table('sm_class_times')
                ->where('is_break', 0)
                ->where('type', 'class')
                ->where('school_id', $this->school_id)
                ->orderBy('start_time')
                ->get();

            if ($classTimes->isEmpty()) {
                throw new Exception("No class times (periods) configured in the system.");
            }

            // 5. Fetch Week Days (from sm_weekends to know which days are working days)
            $weekDays = DB::table('sm_weekends')
                ->where('is_weekend', 0)
                ->where('school_id', $this->school_id)
                ->orderBy('order')
                ->pluck('id')
                ->toArray();
                
            if (empty($weekDays)) {
                $weekDays = [2, 3, 4, 5, 6]; // Monday to Friday typical IDs
            }

            // 6. CSP / Greedy Engine implementation
            $schedule = [];
            // Shuffle the pool to introduce randomness and avoid getting stuck
            shuffle($pool);

            foreach ($weekDays as $day) {
                foreach ($classTimes as $time) {
                    if (empty($pool)) break 2;

                    // Try to find a subject that has a teacher available at this day/time
                    $slotted = false;
                    foreach ($pool as $idx => $item) {
                        $isTeacherBusy = DB::table('sm_class_routine_updates')
                            ->where('day', $day)
                            ->where('class_period_id', $time->id)
                            ->where('teacher_id', $item['teacher_id'])
                            ->where('school_id', $this->school_id)
                            ->exists();

                        if (!$isTeacherBusy) {
                            // Assign this item to this slot
                            $schedule[] = [
                                'day' => $day,
                                'class_period_id' => $time->id,
                                'start_time' => $time->start_time,
                                'end_time' => $time->end_time,
                                'subject_id' => $item['subject_id'],
                                'teacher_id' => $item['teacher_id'],
                                'class_id' => $class_id,
                                'section_id' => $section_id,
                                'room_id' => 1, // Default room, can be expanded
                                'is_break' => 0,
                                'school_id' => $this->school_id,
                                'academic_id' => $this->academic_id,
                                'created_at' => now(),
                                'updated_at' => now()
                            ];

                            // Remove from pool
                            unset($pool[$idx]);
                            // Re-index pool
                            $pool = array_values($pool);
                            $slotted = true;
                            
                            // Immediately persist to DB to update teacher availability state for the next class's loop if run concurrently
                            // But since we run class-by-class sequentially, we can gather and do an insert at the end. 
                            // Wait, to check teacher availability, we must insert now or maintain state in memory. 
                            // Better maintain state in DB for simplicity of checking `exists()`.
                            DB::table('sm_class_routine_updates')->insert(end($schedule));
                            
                            break;
                        }
                    }
                    
                    if (!$slotted) {
                        // Could not find a free teacher for this slot. It remains free (or backtracking needed).
                        // For a simple greedy approach, leave it free.
                    }
                }
            }

            DB::commit();
            return [
                'status' => true,
                'message' => 'Routine generated successfully!',
                'unallocated' => count($pool) // If pool is not empty, constraints were too tight
            ];

        } catch (Exception $e) {
            DB::rollBack();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }
}
