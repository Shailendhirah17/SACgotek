<?php

return [
    'name' => 'AutomatedTimetable'
];
