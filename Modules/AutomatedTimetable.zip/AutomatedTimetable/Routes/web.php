<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => ['auth', 'subdomain']], function () {
    Route::prefix('automatedtimetable')->group(function() {
        // Main Entry point (Dashboard)
        Route::get('/', 'AutomatedTimetableController@index')->name('automatedtimetable.index');
        
        // Admin Grid Editor
        Route::get('/editor', 'AutomatedTimetableController@editor')->name('automatedtimetable.editor');
        Route::post('/editor', 'AutomatedTimetableController@fetchRoutine')->name('automatedtimetable.fetch');
        
        // Engine Triggers (AJAX)
        Route::post('/generate', 'AutomatedTimetableController@generate')->name('automatedtimetable.generate');
        Route::post('/swap', 'AutomatedTimetableController@swap')->name('automatedtimetable.swap');
        Route::post('/assign', 'AutomatedTimetableController@assign')->name('automatedtimetable.assign');
        Route::post('/free', 'AutomatedTimetableController@free')->name('automatedtimetable.free');

        // Teacher Substitute Workflow
        Route::get('/substitutes', 'AutomatedTimetableController@substitutes')->name('automatedtimetable.substitutes');
        Route::post('/substitutes/assign', 'AutomatedTimetableController@assignSubstitute')->name('automatedtimetable.assign_substitute');
    });
});
