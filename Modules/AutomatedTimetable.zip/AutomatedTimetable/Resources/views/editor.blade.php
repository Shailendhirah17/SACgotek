@extends('backEnd.master')
@section('title')
Automated Timetable Editor
@endsection

@section('mainContent')
<section class="sms-breadcrumb mb-40 white-box">
    <div class="container-fluid">
        <div class="row justify-content-between">
            <h1>Automated Timetable - Grid Editor</h1>
        </div>
    </div>
</section>

<section class="admin-visitor-area up_admin_visitor">
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-lg-12">
                <div class="white-box">
                    <form method="POST" action="{{ route('automatedtimetable.fetch') }}">
                        @csrf
                        <div class="row">
                            <div class="col-lg-4">
                                <label>Select Class</label>
                                <select class="primary_select form-control" name="class_id" id="class_id">
                                    <option data-display="Select Class *" value="">Select Class</option>
                                    @foreach($classes as $class)
                                        <option value="{{ $class->id }}" {{ isset($class_id) && $class_id == $class->id ? 'selected' : '' }}>{{ $class->class_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-4">
                                <label>Select Section</label>
                                <select class="primary_select form-control" name="section_id" id="section_id">
                                    <option data-display="Select Section *" value="">Select Section</option>
                                    <!-- Populated via existing JS usually, but hardcoded 1 for POC -->
                                    <option value="1" {{ isset($section_id) && $section_id == 1 ? 'selected' : '' }}>A</option>
                                    <option value="2" {{ isset($section_id) && $section_id == 2 ? 'selected' : '' }}>B</option>
                                </select>
                            </div>
                            <div class="col-lg-4 mt-30">
                                <button type="submit" class="primary-btn small fix-gr-bg">
                                    Fetch Routine
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        @if(isset($routineMatrix))
        <div class="row mt-40">
            <div class="col-lg-12">
                <div class="white-box text-center mb-20">
                    <form method="POST" action="{{ route('automatedtimetable.generate') }}" style="display:inline-block">
                        @csrf
                        <input type="hidden" name="class_id" value="{{ $class_id }}">
                        <input type="hidden" name="section_id" value="{{ $section_id }}">
                        <button type="submit" class="primary-btn tr-bg">
                            <span class="ti-reload"></span> Auto-Generate Timetable
                        </button>
                    </form>
                </div>
                
                <table class="display school-table school-table-style" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Day / Period</th>
                            @foreach($class_times as $time)
                                <th>{{ $time->period }} <br> <small>{{ date('h:i A', strtotime($time->start_time)) }} - {{ date('h:i A', strtotime($time->end_time)) }}</small></th>
                            @endforeach
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($days as $day)
                            <tr>
                                <td><strong>{{ $day }}</strong></td>
                                @foreach($class_times as $time)
                                    <td>
                                        @if(isset($routineMatrix[$day][$time->id]))
                                            @php $routine = $routineMatrix[$day][$time->id]; @endphp
                                            <div class="mr-10">
                                                <span class="text-primary">{{ $routine->subject_name }}</span><br>
                                                <small>{{ $routine->teacher_name }}</small><br>
                                                <form method="POST" action="{{ route('automatedtimetable.free') }}" style="display:inline-block">
                                                    @csrf
                                                    <input type="hidden" name="routine_id" value="{{ $routine->id }}">
                                                    <button type="submit" class="text-danger" style="border:none;background:none;padding:0"><small><i class="ti-trash"></i> Free</small></button>
                                                </form>
                                            </div>
                                        @else
                                            <!-- Empty Slot -->
                                            <form method="POST" action="{{ route('automatedtimetable.assign') }}">
                                                @csrf
                                                <input type="hidden" name="day" value="{{ $day }}">
                                                <input type="hidden" name="class_period_id" value="{{ $time->id }}">
                                                <input type="hidden" name="class_id" value="{{ $class_id }}">
                                                <input type="hidden" name="section_id" value="{{ $section_id }}">
                                                <select class="form-control" name="subject_id" required style="width:100%; border-radius:5px; padding:2px">
                                                    <option value="">Manually Assign</option>
                                                    @foreach($assignedSubjects as $as)
                                                        <!-- Simplified, ideally we send teacher_id too via explode or multiple selects -->
                                                        <option value="{{ $as->subject_id }}">{{ $as->subject_name }} ({{ $as->teacher_name }})</option>
                                                    @endforeach
                                                </select>
                                                <!-- Assume a secondary hidden input for teacher_id would be managed by JS in real scenario. Simplified for design -->
                                                <input type="hidden" name="teacher_id" value="1"> 
                                                <button type="submit" class="primary-btn small tr-bg mt-2" style="padding:0 5px;">Assign</button>
                                            </form>
                                        @endif
                                    </td>
                                @endforeach
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        @endif
    </div>
</section>
@endsection
