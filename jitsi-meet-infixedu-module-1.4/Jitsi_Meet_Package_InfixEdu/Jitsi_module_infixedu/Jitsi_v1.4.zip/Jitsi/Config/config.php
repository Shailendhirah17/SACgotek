<?php

return [
    'name' => 'Jitsi'
];
